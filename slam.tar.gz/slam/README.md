# SLAM Project

Este projeto demonstra um exemplo básico de mapeamento SLAM usando Python e OpenCV. O projeto é executado dentro de um contêiner Docker para facilitar a configuração do ambiente.

## Estrutura do Projeto

